my_list = [34.7654, 5432, False, 'biliberda', {234: 354, 54: 65}, [785, 574], ('fdh', 352), {564, 76, 'dfh'}]
a = 0

for el in my_list:
    b = a + 1
    print(f'{b} {type(my_list[a])}')
    a = a + 1
